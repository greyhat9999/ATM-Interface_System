package view;

import dao.TransactionDAO;
import dao.UserDAO;
import java.awt.*;
import javax.swing.*;
import model.Transaction;

public class DepositFrame extends JFrame {
    private final int userId;
    private JTextField amountField;

    public DepositFrame(int userId) {
        this.userId = userId;
        setTitle("Deposit");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JLabel amountLabel = new JLabel("Amount to Deposit:");
        amountField = new JTextField(10);
        JButton depositButton = new JButton("Deposit");
        JButton backButton = new JButton("Back");

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));
        panel.add(amountLabel);
        panel.add(amountField);
        panel.add(depositButton);
        panel.add(backButton);
        add(panel);

        depositButton.addActionListener(e -> {
            double amount = Double.parseDouble(amountField.getText());
            UserDAO dao = new UserDAO();
            double currentBalance = dao.getBalance(userId);
            if (currentBalance != -1) {
                double newBalance = currentBalance + amount;
                dao.updateBalance(userId, newBalance);

                // Record transaction
                Transaction transaction = new Transaction(userId, "Deposit", amount, "Deposited via ATM");
                TransactionDAO tdao = new TransactionDAO();
                tdao.addTransaction(transaction);

                JOptionPane.showMessageDialog(null, "Deposit successful!");
            } else {
                JOptionPane.showMessageDialog(null, "Error fetching balance.");
            }
        });

        backButton.addActionListener(e -> {
            new MainMenuFrame(userId).setVisible(true);
            dispose();
        });
    }
}
