package view;

import dao.TransactionDAO;
import dao.UserDAO;
import java.awt.*;
import javax.swing.*;
import model.Transaction;
import model.User;

public class DepositFrame extends JFrame {
    private User currentUser;
    private JTextField amountField;
    
    public DepositFrame(User user) {
        this.currentUser = user;
        initializeUI();
    }
    
    private void initializeUI() {
        setTitle("ATM System - Deposit");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        JLabel titleLabel = new JLabel("Deposit Funds");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        JLabel amountLabel = new JLabel("Amount:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(amountLabel, gbc);
        
        amountField = new JTextField(10);
        gbc.gridx = 1;
        panel.add(amountField, gbc);
        
        JButton depositButton = new JButton("Deposit");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panel.add(depositButton, gbc);
        
        depositButton.addActionListener(e -> processDeposit());
        
        add(panel);
    }
    
    private void processDeposit() {
        try {
            double amount = Double.parseDouble(amountField.getText());
            if (amount <= 0) {
                JOptionPane.showMessageDialog(this, "Amount must be positive");
                return;
            }
            
            UserDAO userDao = new UserDAO();
            if (userDao.updateBalance(currentUser.getUserId(), amount)) {
                Transaction transaction = new Transaction(
                    currentUser.getUserId(),
                    "DEPOSIT",
                    amount,
                    "ATM Deposit"
                );
                
                System.out.println("[DEBUG] Deposit transaction created:");
                System.out.println("User ID: " + transaction.getUserId());
                System.out.println("Amount: " + transaction.getAmount());
                
                boolean saveSuccess = new TransactionDAO().addTransaction(transaction);
                System.out.println("[DEBUG] Save status: " + saveSuccess);
                
                if (saveSuccess) {
                    JOptionPane.showMessageDialog(this, 
                        String.format("$%.2f deposited successfully", amount));
                    dispose();
                    new MainMenuFrame(currentUser).setVisible(true);
                }
            }
        } catch (Exception e) {
            System.err.println("[ERROR] Deposit failed:");
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
}