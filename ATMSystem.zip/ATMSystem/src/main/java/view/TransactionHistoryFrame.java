package view;

import dao.TransactionDAO;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Transaction;

public class TransactionHistoryFrame extends JFrame {
    public TransactionHistoryFrame(int userId) {
        setTitle("Transaction History");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        String[] columns = {"Type", "Amount", "Date"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);

        TransactionDAO dao = new TransactionDAO();
        List<Transaction> list = dao.getTransactionsByUserId(userId);

        for (Transaction t : list) {
            model.addRow(new Object[]{t.getType(), t.getAmount(), t.getDate()});
        }

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            new MainMenuFrame(userId).setVisible(true);
            dispose();
        });
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}
