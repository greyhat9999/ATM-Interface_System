package view;

import dao.TransactionDAO;
import dao.UserDAO;
import java.awt.*;
import javax.swing.*;
import model.Transaction;

public class WithdrawFrame extends JFrame {
    public WithdrawFrame(int userId) {
        JTextField amt = new JTextField();
        JButton ok = new JButton("Withdraw"), back = new JButton("Back");
        setLayout(new GridLayout(3, 1, 5, 5));
        add(new JLabel("Enter amount to withdraw:"));
        add(amt);
        JPanel p = new JPanel();
        p.add(ok);
        p.add(back);
        add(p);

        ok.addActionListener(e -> {
            double a = Double.parseDouble(amt.getText());
            UserDAO dao = new UserDAO();
            double bal = dao.getBalance(userId);
            if (bal >= a) {
                dao.updateBalance(userId, bal - a);

                // Record transaction
                Transaction transaction = new Transaction(userId, "Withdraw", a, "Withdrew via ATM");
                TransactionDAO tdao = new TransactionDAO();
                tdao.addTransaction(transaction);

                JOptionPane.showMessageDialog(this, "Withdrew ₹" + a);
            } else {
                JOptionPane.showMessageDialog(this, "Insufficient funds");
            }
        });

        back.addActionListener(e -> {
            new MainMenuFrame(userId).setVisible(true);
            dispose();
        });

        setTitle("Withdraw");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
}
