package view;

import dao.TransactionDAO;
import dao.UserDAO;
import java.awt.*;
import javax.swing.*;
import model.Transaction;
import model.User;

public class WithdrawFrame extends JFrame {
    private User currentUser;
    private JTextField amountField;
    
    public WithdrawFrame(User user) {
        this.currentUser = user;
        initializeUI();
    }
    
    private void initializeUI() {
        setTitle("ATM System - Withdraw");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        JLabel titleLabel = new JLabel("Withdraw Funds");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        JLabel amountLabel = new JLabel("Amount:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(amountLabel, gbc);
        
        amountField = new JTextField(10);
        gbc.gridx = 1;
        panel.add(amountField, gbc);
        
        JButton withdrawButton = new JButton("Withdraw");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panel.add(withdrawButton, gbc);
        
        withdrawButton.addActionListener(e -> processWithdrawal());
        
        add(panel);
    }
    
    private void processWithdrawal() {
        try {
            double amount = Double.parseDouble(amountField.getText());
            if (amount <= 0) {
                JOptionPane.showMessageDialog(this, "Amount must be positive");
                return;
            }
            
            UserDAO userDao = new UserDAO();
            double balance = userDao.getBalance(currentUser.getUserId());
            
            if (amount > balance) {
                JOptionPane.showMessageDialog(this, "Insufficient funds");
                return;
            }
            
            // Update balance
            if (userDao.updateBalance(currentUser.getUserId(), -amount)) {
                // Create and save transaction
                Transaction transaction = new Transaction(
                    currentUser.getUserId(), 
                    "WITHDRAWAL", 
                    amount, 
                    "ATM Withdrawal"
                );
                
                System.out.println("[DEBUG] Withdrawal transaction created:");
                System.out.println("User ID: " + transaction.getUserId());
                System.out.println("Amount: " + transaction.getAmount());
                
                boolean saveSuccess = new TransactionDAO().addTransaction(transaction);
                System.out.println("[DEBUG] Save status: " + saveSuccess);
                
                if (saveSuccess) {
                    JOptionPane.showMessageDialog(this, 
                        String.format("$%.2f withdrawn successfully", amount));
                    dispose();
                    new MainMenuFrame(currentUser).setVisible(true);
                }
            }
        } catch (Exception e) {
            System.err.println("[ERROR] Withdrawal failed:");
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
}