package view;

import dao.UserDAO;
import java.awt.*;
import javax.swing.*;

public class MainMenuFrame extends JFrame {
    private final int userId;

    public MainMenuFrame(int userId) {
        this.userId = userId;

        setTitle("Main Menu");
        setSize(300, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 1, 10, 10));

        JButton depositButton = new JButton("Deposit");
        JButton withdrawButton = new JButton("Withdraw");
        JButton checkBalanceButton = new JButton("Check Balance");
        JButton transactionHistoryButton = new JButton("Transaction History");
        JButton logoutButton = new JButton("Logout");

        add(new JLabel("Select an option:", SwingConstants.CENTER));
        add(depositButton);
        add(withdrawButton);
        add(checkBalanceButton);
        add(transactionHistoryButton);
        add(logoutButton);

        depositButton.addActionListener(e -> {
            new DepositFrame(userId).setVisible(true);
            dispose();
        });

        withdrawButton.addActionListener(e -> {
            new WithdrawFrame(userId).setVisible(true);
            dispose();
        });

        checkBalanceButton.addActionListener(e -> {
            UserDAO dao = new UserDAO();
            double balance = dao.getBalance(userId);
            JOptionPane.showMessageDialog(this, "Your Balance: ₹" + balance);
        });

        transactionHistoryButton.addActionListener(e -> {
            new TransactionHistoryFrame(userId).setVisible(true);
            dispose();
        });

        logoutButton.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });
    }
}
