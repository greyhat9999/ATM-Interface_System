package view;

import dao.UserDAO;
import java.awt.*;
import java.sql.SQLException;
import javax.swing.*;
import model.User;

public class MainMenuFrame extends JFrame {
    private final User currentUser;
    
    public MainMenuFrame(User user) {
        this.currentUser = user;
        initializeUI();
    }
    
    private void initializeUI() {
        setTitle("ATM System - Main Menu");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel welcomeLabel = new JLabel("Welcome, " + currentUser.getName(), SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        
        JButton balanceButton = new JButton("Check Balance");
        JButton withdrawButton = new JButton("Withdraw");
        JButton depositButton = new JButton("Deposit");
        JButton exitButton = new JButton("Exit");
        
        Font buttonFont = new Font("Arial", Font.PLAIN, 18);
        balanceButton.setFont(buttonFont);
        withdrawButton.setFont(buttonFont);
        depositButton.setFont(buttonFont);
        exitButton.setFont(buttonFont);
        
        balanceButton.addActionListener(e -> showBalance());
        withdrawButton.addActionListener(e -> openWithdrawFrame());
        depositButton.addActionListener(e -> openDepositFrame());
        exitButton.addActionListener(e -> logout());
        
        panel.add(welcomeLabel);
        panel.add(balanceButton);
        panel.add(withdrawButton);
        panel.add(depositButton);
        panel.add(exitButton);
        
        add(panel);
    }
    
    private void showBalance() {
        try {
            double balance = new UserDAO().getBalance(currentUser.getUserId());
            JOptionPane.showMessageDialog(this, 
                String.format("Your balance is: $%.2f", balance), 
                "Account Balance", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Error retrieving balance: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void openWithdrawFrame() {
        new WithdrawFrame(currentUser).setVisible(true);
        dispose();
    }
    
    private void openDepositFrame() {
        new DepositFrame(currentUser).setVisible(true);
        dispose();
    }
    
    private void logout() {
        dispose();
        new LoginFrame().setVisible(true);
    }
}