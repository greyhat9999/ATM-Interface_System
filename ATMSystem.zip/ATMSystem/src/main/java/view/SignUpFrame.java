package view;

import dao.UserDAO;
import java.awt.*;
import javax.swing.*;

public class SignUpFrame extends JFrame {
    private JTextField userIdField;
    private JPasswordField pinField;

    public SignUpFrame() {
        setTitle("Sign Up");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 1));

        userIdField = new JTextField();
        pinField = new JPasswordField();

        JButton registerButton = new JButton("Register");
        JButton backButton = new JButton("Back");

        add(new JLabel("User ID:"));
        add(userIdField);
        add(new JLabel("PIN:"));
        add(pinField);
        add(registerButton);
        add(backButton);

        registerButton.addActionListener(e -> {
            try {
                int userId = Integer.parseInt(userIdField.getText());
                String pin = new String(pinField.getPassword());

                if (UserDAO.registerUser(userId, pin)) {
                    JOptionPane.showMessageDialog(this, "User registered successfully!");
                    new LoginFrame().setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "User already exists or error occurred");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid User ID");
            }
        });

        backButton.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });
    }
}
