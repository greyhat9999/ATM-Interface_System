package view;

import dao.UserDAO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {
    private JTextField userIdField;
    private JPasswordField pinField;

    public LoginFrame() {
        setTitle("ATM Login");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        userIdField = new JTextField();
        pinField = new JPasswordField();

        JButton loginButton = new JButton("Login");
        JButton signUpButton = new JButton("Sign Up");

        add(new JLabel("User ID:"));
        add(userIdField);
        add(new JLabel("PIN:"));
        add(pinField);
        add(loginButton);
        add(signUpButton);

        loginButton.addActionListener(e -> {
            int userId = Integer.parseInt(userIdField.getText());
            String pin = new String(pinField.getPassword());
            UserDAO dao = new UserDAO();
            if (dao.validateUser(userId, pin)) {
                new MainMenuFrame(userId).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid User ID or PIN");
            }
        });

        signUpButton.addActionListener(e -> {
            new SignUpFrame().setVisible(true);
            dispose();
        });
    }
}
