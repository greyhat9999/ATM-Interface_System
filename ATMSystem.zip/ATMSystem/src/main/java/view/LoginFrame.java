package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import dao.UserDAO;
import model.User;
import java.sql.SQLException;

public class LoginFrame extends JFrame {
    private JTextField userIdField;
    private JPasswordField pinField;
    private UserDAO userDao;
    
    public LoginFrame() {
        userDao = new UserDAO();
        initializeUI();
    }
    
    private void initializeUI() {
        setTitle("ATM System - Login");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Title
        JLabel titleLabel = new JLabel("ATM SYSTEM");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(titleLabel, gbc);
        
        // User ID
        JLabel userIdLabel = new JLabel("User ID:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        panel.add(userIdLabel, gbc);
        
        userIdField = new JTextField(15);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        panel.add(userIdField, gbc);
        
        // PIN
        JLabel pinLabel = new JLabel("PIN:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_END;
        panel.add(pinLabel, gbc);
        
        pinField = new JPasswordField(15);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        panel.add(pinField, gbc);
        
        // Login Button
        JButton loginButton = new JButton("Login");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(loginButton, gbc);
        
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int userId = Integer.parseInt(userIdField.getText());
                    String pin = new String(pinField.getPassword());
                    
                    User user = userDao.getUser(userId, pin);
                    if (user != null) {
                        dispose();
                        new MainMenuFrame(user).setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(LoginFrame.this, 
                            "Invalid User ID or PIN", "Login Failed", 
                            JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(LoginFrame.this, 
                        "User ID must be a number", "Invalid Input", 
                        JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(LoginFrame.this, 
                        "Database error: " + ex.getMessage(), "Error", 
                        JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });
        
        add(panel);
    }
}