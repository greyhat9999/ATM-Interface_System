package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Transaction;

public class TransactionDAO {
    public List<Transaction> getTransactionsByUserId(int userId) {
        List<Transaction> list = new ArrayList<>();
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT type, amount, timestamp FROM transactions WHERE user_id = ? ORDER BY timestamp DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Transaction t = new Transaction();
                t.setType(rs.getString("type"));
                t.setAmount(rs.getDouble("amount"));
                t.setTimestamp(rs.getTimestamp("timestamp"));
                list.add(t);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void addTransaction(Transaction t) {
    try {
        Connection conn = DBConnection.getConnection();
        String sql = "INSERT INTO transactions (user_id, type, amount, timestamp, description) VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, t.getUserId());
        ps.setString(2, t.getType());
        ps.setDouble(3, t.getAmount());
        ps.setString(4, t.getDescription());
        ps.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }

}

}

