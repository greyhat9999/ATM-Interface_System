package dao;

import java.sql.*;
import model.Transaction;

public class TransactionDAO {
    public boolean addTransaction(Transaction transaction) {
        String sql = "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, transaction.getUserId());
            stmt.setString(2, transaction.getType());
            stmt.setDouble(3, transaction.getAmount());
            stmt.setString(4, transaction.getDescription());
            
            int rowsAffected = stmt.executeUpdate();
            System.out.println("[DEBUG] Transaction rows affected: " + rowsAffected);
            
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("[ERROR] Failed to save transaction:");
            e.printStackTrace();
            return false;
        }
    }
}