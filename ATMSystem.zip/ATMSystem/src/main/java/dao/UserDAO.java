package dao;

import java.sql.*;

public class UserDAO {

    private static Connection conn;

    static {
        try {
            conn = DBConnection.getConnection();
        } catch (SQLException e) {
            e.printStackTrace(); // Optional: log if DB connection fails
        }
    }

    public static boolean registerUser(int userId, String pin) {
        try (PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO users (user_id, pin, balance) VALUES (?, ?, 0.0)")) {
            stmt.setInt(1, userId);
            stmt.setString(2, pin);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean validateUser(int userId, String pin) {
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT 1 FROM users WHERE user_id = ? AND pin = ?")) {
            stmt.setInt(1, userId);
            stmt.setString(2, pin);
            return stmt.executeQuery().next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public double getBalance(int userId) {
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT balance FROM users WHERE user_id = ?")) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean updateBalance(int userId, double bal) {
        try (PreparedStatement stmt = conn.prepareStatement(
                "UPDATE users SET balance = ? WHERE user_id = ?")) {
            stmt.setDouble(1, bal);
            stmt.setInt(2, userId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
