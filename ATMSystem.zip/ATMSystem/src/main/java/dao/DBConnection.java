package dao;

import java.sql.*;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/atm_system?useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "mysqlpass12@";

    private static Connection connection;

    static {
        try {
            initializeDatabase();
        } catch (SQLException e) {
            System.err.println("[ERROR] Failed to initialize database:");
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                System.out.println("[DEBUG] Connecting to database...");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                connection.setAutoCommit(true);
                System.out.println("[DEBUG] Database connection successful!");
            } catch (SQLException e) {
                System.err.println("[ERROR] Database connection failed:");
                e.printStackTrace();
                throw e;
            }
        }
        return connection;
    }

    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("[DEBUG] Database connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void initializeDatabase() throws SQLException {
        String createDB = "CREATE DATABASE IF NOT EXISTS atm_system";
        String createUsersTable = """
                CREATE TABLE IF NOT EXISTS users (
                    user_id INT PRIMARY KEY,
                    name VARCHAR(100),
                    pin CHAR(64),
                    balance DOUBLE
                )
                """;
        String createTransactionsTable = """
                CREATE TABLE IF NOT EXISTS transactions (
                    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT,
                    type VARCHAR(20),
                    amount DOUBLE,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    description VARCHAR(255),
                    FOREIGN KEY (user_id) REFERENCES users(user_id)
                )
                """;

        try (Connection initConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/?useSSL=false", USER, PASSWORD);
             Statement stmt = initConn.createStatement()) {

            stmt.executeUpdate(createDB);
            System.out.println("[DEBUG] Database 'atm_system' created or already exists.");

            try (Connection dbConn = DriverManager.getConnection(URL, USER, PASSWORD);
                 Statement dbStmt = dbConn.createStatement()) {
                dbStmt.executeUpdate(createUsersTable);
                System.out.println("[DEBUG] Table 'users' created or already exists.");

                dbStmt.executeUpdate(createTransactionsTable);
                System.out.println("[DEBUG] Table 'transactions' created or already exists.");
            }
        }
    }
}
