package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/atm_system?useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "mysqlpass12@";
    
    private static Connection connection;
    
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                System.out.println("[DEBUG] Connecting to database...");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                connection.setAutoCommit(true); // Ensure auto-commit is enabled
                System.out.println("[DEBUG] Database connection successful!");
            } catch (SQLException e) {
                System.err.println("[ERROR] Database connection failed:");
                e.printStackTrace();
                throw e;
            }
        }
        return connection;
    }
    
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("[DEBUG] Database connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}